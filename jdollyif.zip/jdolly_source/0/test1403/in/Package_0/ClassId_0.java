package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_1(){
    fieldid_0=fieldid_0 + fieldid_1;
    return fieldid_0;
  }
  private int fieldid_1=2;
}
