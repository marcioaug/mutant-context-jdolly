package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_0(  int param){
    return 01 % param;
  }
  public int methodid_0(){
    fieldid_0=fieldid_1 + fieldid_0;
    return fieldid_0;
  }
  private int fieldid_0=0;
}
