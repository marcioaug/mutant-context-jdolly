package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_0(  int param){
    return param;
  }
  public int methodid_0(){
    fieldid_0=fieldid_0 + fieldid_1;
    return fieldid_0;
  }
  public int methodid_1(  int param){
    if (fieldid_0 > param)     return --fieldid_0;
    return fieldid_1;
  }
  protected int fieldid_1=1;
}
