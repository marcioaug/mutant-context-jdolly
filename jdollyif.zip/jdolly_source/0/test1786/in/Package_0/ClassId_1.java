package Package_0;
public class ClassId_1 {
  int fieldid_0=2;
  protected int fieldid_1=-1;
}
