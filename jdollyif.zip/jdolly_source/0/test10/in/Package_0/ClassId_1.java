package Package_0;
public class ClassId_1 {
  public int methodid_0(){
    return ClassId_1.this.fieldid_0;
  }
  public int methodid_1(  int param){
    if (fieldid_0 >= param)     return fieldid_0 * fieldid_1;
    return fieldid_0;
  }
  private int fieldid_1=2;
  protected int fieldid_0=1;
}
