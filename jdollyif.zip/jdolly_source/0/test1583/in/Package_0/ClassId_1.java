package Package_0;
public class ClassId_1 {
  public int methodid_0(){
    return ClassId_1.this.fieldid_1;
  }
  private int fieldid_1=-1;
}
