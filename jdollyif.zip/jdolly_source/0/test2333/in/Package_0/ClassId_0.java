package Package_0;
public class ClassId_0 extends ClassId_1 {
  protected int fieldid_1=0;
}
