package Package_0;
public class ClassId_0 extends ClassId_1 {
  private int fieldid_0=0;
}
