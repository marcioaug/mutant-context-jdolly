package Package_0;
public class ClassId_0 {
  public int methodid_0(  int param){
    return 01 - param;
  }
  public int methodid_0(){
    return fieldid_1;
  }
  int fieldid_0=-1;
  int fieldid_1=2;
}
