package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_1(){
    return super.methodid_0(2);
  }
  protected int fieldid_1=2;
}
