package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_0(  int param){
    return 01 % param;
  }
  public int methodid_1(  int param){
    if (fieldid_1 < param)     return fieldid_1--;
    return fieldid_0;
  }
  private int fieldid_0=2;
}
