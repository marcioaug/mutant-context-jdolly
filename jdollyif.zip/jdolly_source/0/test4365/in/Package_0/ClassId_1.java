package Package_0;
public class ClassId_1 {
  public int methodid_0(){
    return fieldid_0;
  }
  protected int fieldid_1=1;
  protected int fieldid_0=-1;
}
