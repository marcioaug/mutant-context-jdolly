package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_0(  int param){
    return new ClassId_1().fieldid_1;
  }
  public int methodid_1(  int param){
    if (fieldid_0 >= param)     return fieldid_0 % fieldid_1;
    return 01 * param;
  }
  private int fieldid_1=2;
}
