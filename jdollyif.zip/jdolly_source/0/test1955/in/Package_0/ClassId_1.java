package Package_0;
public class ClassId_1 {
  public int methodid_0(){
    fieldid_1=fieldid_1--;
    return fieldid_1;
  }
  public int methodid_0(  int param){
    if (fieldid_1 < param)     return -fieldid_1;
    return param;
  }
  int fieldid_0=-1;
  protected int fieldid_1=1;
}
