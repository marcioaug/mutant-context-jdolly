package Package_0;
public class ClassId_1 {
  public int methodid_1(  int param){
    return ClassId_1.this.methodid_0() - param;
  }
  public int methodid_0(){
    fieldid_1=fieldid_0++;
    return fieldid_1;
  }
  public int fieldid_1=-1;
  protected int fieldid_0=2;
}
