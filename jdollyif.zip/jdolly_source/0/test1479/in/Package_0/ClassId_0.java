package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_1(){
    return this.methodid_0(2);
  }
  public int methodid_1(  int param){
    if (fieldid_0 < param)     fieldid_0++;
    return fieldid_0;
  }
  private int fieldid_1=2;
}
