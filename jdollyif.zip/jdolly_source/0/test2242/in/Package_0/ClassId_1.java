package Package_0;
public class ClassId_1 {
  public int methodid_1(  int param){
    return 01 % param;
  }
  public int fieldid_1=0;
  private int fieldid_0=0;
}
