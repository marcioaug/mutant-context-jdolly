package Package_0;
public class ClassId_0 extends ClassId_1 {
  public int methodid_0(){
    return methodid_1(2);
  }
  protected int fieldid_1=-1;
}
