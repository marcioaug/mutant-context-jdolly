package Package_0;
public class ClassId_1 {
  public int methodid_1(){
    return new ClassId_0().fieldid_1;
  }
  private int fieldid_0=-2;
}
