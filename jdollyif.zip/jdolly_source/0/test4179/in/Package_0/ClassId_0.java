package Package_0;
public class ClassId_0 {
  public int methodid_0(){
    return new ClassId_0().fieldid_1;
  }
  public int methodid_1(){
    return fieldid_1;
  }
  int fieldid_0=-2;
  int fieldid_1=-1;
}
